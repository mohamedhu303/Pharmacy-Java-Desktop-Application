package dao;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 * Class to create necessary tables and handle database operations.
 */
public class Tables { // Changed class name to PascalCase

    public static void main(String[] args) {

        Connection con = null;
        Statement st = null;

        try {
            // Get connection from ConnectionProvider class
            con = ConnectionProvider.getCon();
            st = con.createStatement();

// Create customer table
            st.executeUpdate("CREATE TABLE IF NOT EXISTS customer ("
                    + "CUSTOMER_pk INT AUTO_INCREMENT PRIMARY KEY, "
                    + "NAME VARCHAR(200), "
                    + "MOBILENUMBER VARCHAR(500), "
                    + "EMAIL VARCHAR(200)"
                    + ") ENGINE=InnoDB;");

// Create category table
            st.executeUpdate("CREATE TABLE IF NOT EXISTS category ("
                    + "category_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "name VARCHAR(200) NOT NULL"
                    + ") ENGINE=InnoDB;");

// Create product table with a foreign key to category table
            st.executeUpdate("CREATE TABLE IF NOT EXISTS product ("
                    + "product_pk INT AUTO_INCREMENT PRIMARY KEY, "
                    + "name VARCHAR(200) NOT NULL, "
                    + "quantity INT NOT NULL, "
                    + "price INT NOT NULL, "
                    + "description VARCHAR(500), "
                    + "category_fk INT "
                    + ") ENGINE=InnoDB;");

            // Create product table with a foreign key to category table
            st.executeUpdate("CREATE TABLE IF NOT EXISTS order ("
                    + "order_pk INT AUTO_INCREMENT PRIMARY KEY, "
                    + "orderId VARCHAR(200),"
                    + "customer_fk int,"
                    + "orderDate varchar(200),"
                    + "totalPaid int");
            
// Create appuser table with proper data types and constraints
            st.executeUpdate("CREATE TABLE IF NOT EXISTS appuser ("
                    + "appuser_pk INT AUTO_INCREMENT PRIMARY KEY, "
                    + "userRole VARCHAR(50) NOT NULL, "
                    + "name VARCHAR(200) NOT NULL, "
                    + "mobileName VARCHAR(50) NOT NULL, "
                    + "email VARCHAR(200) UNIQUE, "
                    + "password VARCHAR(50) NOT NULL, "
                    + "address VARCHAR(200) NOT NULL, "
                    + "status VARCHAR(50) NOT NULL"
                    + ") ENGINE=InnoDB;");

// Insert data into appuser table
            st.executeUpdate("INSERT INTO appuser (userRole, name, mobileName, email, password, address, status) "
                    + "VALUES ('SuperAdmin', 'Super Admin', '12345', 'superadmin@gmail.com', 'admin', 'India', 'Active')");

            JOptionPane.showMessageDialog(null, "Tables created successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage()); // Use getMessage() for better error message
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
                if (st != null) {
                    st.close();
                }
            } catch (Exception e) {
                // Handle connection/statement closing exceptions here (optional)
            }
        }
    }
}
